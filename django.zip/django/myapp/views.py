from django.shortcuts import render
from . import models



def index(request):
    mods=models.NewModel.objects.all()
    return render(request, 'index.html', {'mods': mods})